
import { Injectable, signal } from '@angular/core';
import { fromEvent, startWith, map } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class NetworkService {
  isOnline = signal<boolean>(true);

  constructor() {
    if (typeof window !== 'undefined') {
      this.isOnline.set(navigator.onLine);
      fromEvent(window, 'online').subscribe(() => this.isOnline.set(true));
      fromEvent(window, 'offline').subscribe(() => this.isOnline.set(false));
    }
  }
}

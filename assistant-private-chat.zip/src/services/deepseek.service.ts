
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class DeepseekService {
  
  async generateResponse(apiKey: string, prompt: string, modelId: string): Promise<string> {
    const API_URL = 'https://api.deepseek.com/chat/completions';
    
    const systemPromptEnd = prompt.indexOf('\n\n[USER KNOWLEDGE CONTEXT]:');
    const systemPrompt = prompt.substring(0, systemPromptEnd).trim();
    const userContent = prompt.substring(systemPromptEnd).trim();

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: modelId,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userContent }
          ]
        })
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('INVALID_API_KEY');
        }
        const errorData = await response.json();
        throw new Error(errorData.error?.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || 'No response from DeepSeek.';

    } catch (error) {
      console.error('DeepSeek API Error:', error);
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('An unknown error occurred with the DeepSeek API.');
    }
  }

  async verifyApiKey(apiKey: string): Promise<boolean> {
    try {
      const response = await fetch('https://api.deepseek.com/v1/models', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`
        }
      });
      return response.ok;
    } catch (error) {
      console.error('DeepSeek API Key verification failed:', error);
      return false;
    }
  }
}

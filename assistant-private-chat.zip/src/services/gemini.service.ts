
import { Injectable } from '@angular/core';
import { GoogleGenAI } from '@google/genai';

@Injectable({ providedIn: 'root' })
export class GeminiService {
  
  async generateResponse(apiKey: string, prompt: string, modelId: string): Promise<string> {
    try {
      // We create a new instance per request because the API key can change.
      // In a real app, you might manage this instance more carefully.
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: modelId,
        contents: prompt,
      });

      return response.text;
    } catch (error) {
      console.error('Gemini API Error:', error);
      if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
          throw new Error('INVALID_API_KEY');
        }
        throw new Error(`Gemini API Error: ${error.message}`);
      }
      throw new Error('An unknown error occurred with the Gemini API.');
    }
  }

  async verifyApiKey(apiKey: string, modelId: string): Promise<boolean> {
    try {
      const ai = new GoogleGenAI({ apiKey });
      await ai.models.generateContent({ model: modelId, contents: 'test' });
      return true;
    } catch (error) {
      console.warn('Gemini verification check error:', error);
      if (error instanceof Error && error.message.includes('API key not valid')) {
        return false;
      }
      // For any other error (e.g., model access, quota), we assume the key itself is valid for the provider.
      return true;
    }
  }
}


import { Injectable, signal, effect } from '@angular/core';
import { KnowledgeItem } from '../models/ai.model';

@Injectable({ providedIn: 'root' })
export class KnowledgeService {
  private readonly KNOWLEDGE_STORAGE_KEY = 'assistant_private_chat_knowledge';

  knowledgeBase = signal<KnowledgeItem[]>(this.loadKnowledge());

  constructor() {
    effect(() => {
      this.saveKnowledge(this.knowledgeBase());
    });
  }

  addKnowledge(name: string, content: string) {
    const newItem: KnowledgeItem = {
      id: self.crypto.randomUUID(),
      name,
      content,
      createdAt: Date.now(),
    };
    this.knowledgeBase.update(current => [...current, newItem]);
  }

  deleteKnowledge(id: string) {
    this.knowledgeBase.update(current => current.filter(item => item.id !== id));
  }
  
  clearKnowledge() {
    this.knowledgeBase.set([]);
  }

  getAllKnowledgeAsString(): string {
    return this.knowledgeBase().map(item => item.content).join('\n\n---\n\n');
  }

  private saveKnowledge(knowledge: KnowledgeItem[]) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.KNOWLEDGE_STORAGE_KEY, JSON.stringify(knowledge));
    }
  }

  private loadKnowledge(): KnowledgeItem[] {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(this.KNOWLEDGE_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    }
    return [];
  }
}

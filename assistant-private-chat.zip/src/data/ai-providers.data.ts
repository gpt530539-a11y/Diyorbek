
import { AiProviderType } from '../models/ai.model';

export interface AiModel {
  id: string;
  name: string;
}

export interface AiProvider {
  id: AiProviderType;
  name: string;
  models: AiModel[];
  disabled?: boolean;
}

export const AI_PROVIDERS: AiProvider[] = [
  {
    id: 'gemini',
    name: 'Google Gemini',
    models: [
      { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash' },
      { id: 'gemini-1.5-pro-latest', name: 'Gemini 1.5 Pro' },
      { id: 'gemini-1.5-flash-latest', name: 'Gemini 1.5 Flash' },
      { id: 'gemini-pro', name: 'Gemini 1.0 Pro' },
    ],
  },
  {
    id: 'openai',
    name: 'OpenAI',
    models: [
      { id: 'gpt-4o', name: 'GPT-4o' },
      { id: 'gpt-4o-mini', name: 'GPT-4o mini' },
      { id: 'o1-preview', name: 'o1-preview' },
      { id: 'o1-mini', name: 'o1-mini' },
      { id: 'gpt-4-turbo', name: 'GPT-4 Turbo' },
      { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo' },
    ],
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    models: [
        { id: 'deepseek-v3', name: 'DeepSeek-V3' },
        { id: 'deepseek-r1', name: 'DeepSeek-R1' },
        { id: 'deepseek-chat', name: 'DeepSeek-Chat' },
    ],
  }
];


import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SettingsService } from '../../services/settings.service';
import { KnowledgeService } from '../../services/knowledge.service';
import { TranslationService } from '../../services/translation.service';
import { AiProviderType, Theme, Language } from '../../models/ai.model';
import { TermsComponent } from '../terms/terms.component';
import { HelpSettingsComponent } from '../help-settings/help-settings.component';
import { AI_PROVIDERS, AiModel } from '../../data/ai-providers.data';
import { AiService } from '../../services/ai.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, TermsComponent, HelpSettingsComponent],
})
export class SettingsComponent {
  settingsService = inject(SettingsService);
  knowledgeService = inject(KnowledgeService);
  translationService = inject(TranslationService);
  aiService = inject(AiService);

  apiKey = signal(this.settingsService.apiKey() || '');
  provider = signal(this.settingsService.provider() || 'gemini');
  modelId = signal(this.settingsService.modelId() || '');
  theme = signal(this.settingsService.theme());
  language = signal(this.settingsService.language());
  
  showTerms = signal(false);
  showHelp = signal(false);
  toastMessage = signal('');
  isVerifying = signal(false);
  verificationError = signal<string | null>(null);

  providers = AI_PROVIDERS;

  availableModels = computed<AiModel[]>(() => {
    const selectedProvider = this.providers.find(p => p.id === this.provider());
    return selectedProvider ? selectedProvider.models : [];
  });

  // Translated text signals
  aiProviderSettings = this.translationService.translate('aiProviderSettings');
  aiProviderLabel = this.translationService.translate('aiProviderLabel');
  aiModelLabel = this.translationService.translate('aiModelLabel');
  apiKeyLabel = this.translationService.translate('apiKeyLabel');
  apiKeyPlaceholder = this.translationService.translate('apiKeyPlaceholder');
  updateSettingsLabel = this.translationService.translate('updateSettings');
  displaySettings = this.translationService.translate('displaySettings');
  themeLabel = this.translationService.translate('theme');
  languageLabel = this.translationService.translate('language');
  lightTheme = this.translationService.translate('lightTheme');
  darkTheme = this.translationService.translate('darkTheme');
  systemTheme = this.translationService.translate('systemTheme');
  english = this.translationService.translate('english');
  uzbek = this.translationService.translate('uzbek');
  russian = this.translationService.translate('russian');
  termsAndInfo = this.translationService.translate('termsAndInfo');
  viewTerms = this.translationService.translate('viewTerms');
  viewHelp = this.translationService.translate('viewHelp');
  developerInfoTitle = this.translationService.translate('developerInfoTitle');
  developerName = this.translationService.translate('developerName');
  developerYear = this.translationService.translate('developerYear');
  developerEmail = this.translationService.translate('developerEmail');
  dangerZone = this.translationService.translate('dangerZone');
  dangerZoneDescription = this.translationService.translate('dangerZoneDescription');
  logOut = this.translationService.translate('logOut');
  deleteAllDataLabel = this.translationService.translate('deleteAllData');
  termsOfUse = this.translationService.translate('termsOfUse');
  helpCenter = this.translationService.translate('helpCenter');
  close = this.translationService.translate('close');
  verifyingApiKey = this.translationService.translate('verifyingApiKey');

  private settingsUpdatedMsg = this.translationService.translate('settingsUpdated');
  private settingsInvalidMsg = this.translationService.translate('settingsInvalid');
  private confirmLogoutMsg = this.translationService.translate('areYouSureLogOut');
  private confirmDeleteAllDataMsg = this.translationService.translate('areYouSureDeleteAllData');
  private apiKeyInvalidForProvider = this.translationService.translate('apiKeyInvalidForProvider');


  async updateSettings() {
    if (!this.apiKey().trim() || !this.provider() || !this.modelId()) {
      alert(this.settingsInvalidMsg());
      return;
    }
    
    this.isVerifying.set(true);
    this.verificationError.set(null);

    const isValid = await this.aiService.verifyApiKey(
      this.apiKey().trim(),
      this.provider(),
      this.modelId()
    );
    
    this.isVerifying.set(false);

    if (isValid) {
      this.settingsService.saveSettings(this.apiKey().trim(), this.provider(), this.modelId());
      this.showToast(this.settingsUpdatedMsg());
    } else {
      this.verificationError.set(this.apiKeyInvalidForProvider());
    }
  }

  private showToast(message: string) {
    this.toastMessage.set(message);
    setTimeout(() => this.toastMessage.set(''), 3000);
  }

  onProviderChange() {
    this.verificationError.set(null);
    const models = this.availableModels();
    if (models.length > 0) {
      this.modelId.set(models[0].id);
    } else {
      this.modelId.set('');
    }
  }

  updateTheme(event: Event) {
    const newTheme = (event.target as HTMLSelectElement).value as Theme;
    this.theme.set(newTheme);
    this.settingsService.setTheme(newTheme);
  }

  updateLanguage(event: Event) {
    const newLanguage = (event.target as HTMLSelectElement).value as Language;
    this.language.set(newLanguage);
    this.settingsService.setLanguage(newLanguage);
  }
  
  logout() {
    if (confirm(this.confirmLogoutMsg())) {
        this.settingsService.clearSettings();
    }
  }
  
  deleteAllData() {
    if (confirm(this.confirmDeleteAllDataMsg())) {
        this.knowledgeService.clearKnowledge();
        this.settingsService.clearSettings();
    }
  }

  toggleTerms() {
      this.showTerms.update(v => !v);
  }

  toggleHelp() {
      this.showHelp.update(v => !v);
  }
}

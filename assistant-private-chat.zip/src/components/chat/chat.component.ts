
import { Component, ChangeDetectionStrategy, inject, signal, ElementRef, viewChild, afterNextRender } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AiService } from '../../services/ai.service';
import { KnowledgeService } from '../../services/knowledge.service';
import { NetworkService } from '../../services/network.service';
import { TranslationService } from '../../services/translation.service';
import { ChatMessage } from '../../models/ai.model';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
})
export class ChatComponent {
  private aiService = inject(AiService);
  knowledgeService = inject(KnowledgeService);
  networkService = inject(NetworkService);
  translationService = inject(TranslationService);
  
  chatContainer = viewChild<ElementRef<HTMLDivElement>>('chatContainer');

  userInput = signal('');
  messages = signal<ChatMessage[]>([]);
  isLoading = signal(false);
  hasKnowledge = this.knowledgeService.knowledgeBase().length > 0;

  // Translated text signals
  startConversation = this.translationService.translate('startConversation');
  askAQuestion = this.translationService.translate('askAQuestion');
  askAQuestionPlaceholder = this.translationService.translate('askAQuestionPlaceholder');
  youAreOffline = this.translationService.translate('youAreOffline');
  addKnowledgePrompt = this.translationService.translate('addKnowledgePrompt');
  private invalidApiKeyMsg = this.translationService.translate('invalidApiKey');

  constructor() {
    afterNextRender(() => {
        this.scrollToBottom();
    });
  }
  
  sendMessage() {
    const message = this.userInput().trim();
    if (!message || this.isLoading() || !this.networkService.isOnline() || !this.hasKnowledge) return;

    this.messages.update(m => [...m, { role: 'user', content: message }]);
    this.userInput.set('');
    this.isLoading.set(true);
    this.scrollToBottom();

    this.aiService.sendMessage(message).pipe(
      catchError(error => {
        console.error('Error sending message:', error);
        let errorMessage: string;
        if (error instanceof Error && error.message === 'INVALID_API_KEY') {
          errorMessage = this.invalidApiKeyMsg();
        } else if (error instanceof Error) {
          errorMessage = `An error occurred: ${error.message}`;
        } else {
          errorMessage = `An unknown error occurred.`;
        }
        return of(errorMessage);
      })
    ).subscribe(response => {
      this.messages.update(m => [...m, { role: 'model', content: response }]);
      this.isLoading.set(false);
      this.scrollToBottom();
    });
  }

  private scrollToBottom(): void {
    try {
      if (this.chatContainer()) {
        const element = this.chatContainer()?.nativeElement;
        if (element) {
          element.scrollTop = element.scrollHeight;
        }
      }
    } catch (err) {
      console.error('Could not scroll to bottom:', err);
    }
  }
}

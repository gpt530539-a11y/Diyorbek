
export type AiProviderType = 'gemini' | 'openai' | 'deepseek';
export type Theme = 'light' | 'dark' | 'system';
export type Language = 'en' | 'uz' | 'ru';

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  content: string;
}

export interface KnowledgeItem {
  id: string;
  name: string;
  content: string;
  createdAt: number;
}

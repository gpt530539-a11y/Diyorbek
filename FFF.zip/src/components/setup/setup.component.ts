
import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SettingsService } from '../../services/settings.service';
import { TranslationService } from '../../services/translation.service';
import { AiProviderType, Language } from '../../models/ai.model';
import { HelpComponent } from '../help/help.component';
import { AI_PROVIDERS, AiModel } from '../../data/ai-providers.data';
import { AiService } from '../../services/ai.service';

@Component({
  selector: 'app-setup',
  templateUrl: './setup.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, HelpComponent],
})
export class SetupComponent {
  settingsService = inject(SettingsService);
  translationService = inject(TranslationService);
  aiService = inject(AiService);

  apiKey = signal('');
  provider = signal<AiProviderType>('gemini');
  modelId = signal('gemini-2.5-flash'); // Default model
  submitted = signal(false);
  showHelp = signal(false);
  showWarningModal = signal(false);
  isVerifying = signal(false);
  verificationError = signal<string | null>(null);
  language = this.settingsService.language;

  providers = AI_PROVIDERS;

  availableModels = computed<AiModel[]>(() => {
    const selectedProvider = this.providers.find(p => p.id === this.provider());
    return selectedProvider ? selectedProvider.models : [];
  });
  
  // Translated text signals
  welcomeMessage = this.translationService.translate('welcomeMessage');
  configurePrompt = this.translationService.translate('configurePrompt');
  aiProviderLabel = this.translationService.translate('aiProviderLabel');
  aiModelLabel = this.translationService.translate('aiModelLabel');
  apiKeyLabel = this.translationService.translate('apiKeyLabel');
  apiKeyPlaceholder = this.translationService.translate('apiKeyPlaceholder');
  apiKeyRequired = this.translationService.translate('apiKeyRequired');
  saveAndContinue = this.translationService.translate('saveAndContinue');
  apiKeyNotice = this.translationService.translate('apiKeyNotice');
  helpLabel = this.translationService.translate('help');
  languageLabel = this.translationService.translate('language');
  english = this.translationService.translate('english');
  uzbek = this.translationService.translate('uzbek');
  russian = this.translationService.translate('russian');
  helpCenter = this.translationService.translate('helpCenter');
  close = this.translationService.translate('close');
  setupWarning = this.translationService.translateObject<any>('setupWarning');
  verifyingApiKey = this.translationService.translate('verifyingApiKey');
  private apiKeyInvalidForProvider = this.translationService.translate('apiKeyInvalidForProvider');


  handleSaveAttempt() {
    this.submitted.set(true);
    this.verificationError.set(null);
    if (this.apiKey().trim() && this.provider() && this.modelId()) {
      this.showWarningModal.set(true);
    }
  }

  async confirmAndSaveSettings() {
    this.isVerifying.set(true);
    
    const isValid = await this.aiService.verifyApiKey(
      this.apiKey().trim(),
      this.provider(),
      this.modelId()
    );

    this.isVerifying.set(false);
    
    if (isValid) {
      this.settingsService.saveSettings(this.apiKey().trim(), this.provider(), this.modelId());
    } else {
      this.verificationError.set(this.apiKeyInvalidForProvider());
      this.showWarningModal.set(false);
    }
  }

  onProviderChange() {
    this.verificationError.set(null);
    const models = this.availableModels();
    if (models.length > 0) {
      this.modelId.set(models[0].id);
    } else {
      this.modelId.set('');
    }
  }

  toggleHelp() {
    this.showHelp.update(v => !v);
  }

  updateLanguage(event: Event) {
    const newLanguage = (event.target as HTMLSelectElement).value as Language;
    this.settingsService.setLanguage(newLanguage);
  }
}


import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { ChatComponent } from '../chat/chat.component';
import { KnowledgeComponent } from '../knowledge/knowledge.component';
import { SettingsComponent } from '../settings/settings.component';
import { TranslationService } from '../../services/translation.service';

type ActiveView = 'chat' | 'knowledge' | 'settings';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ChatComponent, KnowledgeComponent, SettingsComponent],
})
export class MainComponent {
  private translationService = inject(TranslationService);
  activeView = signal<ActiveView>('chat');

  chatLabel = this.translationService.translate('chat');
  knowledgeBaseLabel = this.translationService.translate('knowledgeBase');
  settingsLabel = this.translationService.translate('settings');

  setView(view: ActiveView) {
    this.activeView.set(view);
  }
}


import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-help-settings',
  templateUrl: './help-settings.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HelpSettingsComponent {
  private translationService = inject(TranslationService);

  help = this.translationService.translateObject<any>('helpContentSettings');
}

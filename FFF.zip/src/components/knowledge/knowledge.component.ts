
import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { KnowledgeService } from '../../services/knowledge.service';
import { TranslationService } from '../../services/translation.service';
import { FileParserService } from '../../services/file-parser.service';

@Component({
  selector: 'app-knowledge',
  templateUrl: './knowledge.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
})
export class KnowledgeComponent {
  knowledgeService = inject(KnowledgeService);
  translationService = inject(TranslationService);
  fileParserService = inject(FileParserService);

  manualInput = signal('');
  selectedFile = signal<File | null>(null);
  isParsing = signal(false);
  itemToDelete = signal<string | 'all' | null>(null);

  // Translated text signals
  addKnowledgeManually = this.translationService.translate('addKnowledgeManually');
  pasteKnowledgePlaceholder = this.translationService.translate('pasteKnowledgePlaceholder');
  addText = this.translationService.translate('addText');
  uploadFromFile = this.translationService.translate('uploadFromFile');
  supportedFormats = this.translationService.translate('supportedFormats');
  clickToUpload = this.translationService.translate('clickToUpload');
  addFile = this.translationService.translate('addFile');
  parsingFile = this.translationService.translate('parsingFile');
  currentKnowledgeBase = this.translationService.translate('currentKnowledgeBase');
  clearAll = this.translationService.translate('clearAll');
  knowledgeBaseEmpty = this.translationService.translate('knowledgeBaseEmpty');
  notes = this.translationService.translateObject<any>('knowledgeNotes');
  confirmDeleteButton = this.translationService.translate('confirmDeleteButton');
  cancelDeleteButton = this.translationService.translate('cancelDeleteButton');
  private confirmDeleteAllKnowledgeMsg = this.translationService.translate('areYouSureDeleteKnowledge');
  private confirmDeleteSingleKnowledgeMsg = this.translationService.translate('areYouSureDeleteSingleKnowledge');
  private errorParsingFileMsg = this.translationService.translate('errorParsingFile');
  
  deleteMessage = computed(() => {
    return this.itemToDelete() === 'all'
        ? this.confirmDeleteAllKnowledgeMsg()
        : this.confirmDeleteSingleKnowledgeMsg();
  });

  addManualKnowledge() {
    const content = this.manualInput().trim();
    if (content) {
      const name = content.substring(0, 50) + (content.length > 50 ? '...' : '');
      this.knowledgeService.addKnowledge(name, content);
      this.manualInput.set('');
    }
  }

  deleteKnowledge(id: string) {
    this.itemToDelete.set(id);
  }
  
  clearAllKnowledge() {
    this.itemToDelete.set('all');
  }

  confirmDeletion() {
    const id = this.itemToDelete();
    if (id === 'all') {
      this.knowledgeService.clearKnowledge();
    } else if (id) {
      this.knowledgeService.deleteKnowledge(id);
    }
    this.itemToDelete.set(null);
  }

  cancelDeletion() {
    this.itemToDelete.set(null);
  }

  handleFileInput(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile.set(input.files[0]);
    } else {
      this.selectedFile.set(null);
    }
    input.value = '';
  }

  async addFileKnowledge() {
    const file = this.selectedFile();
    if (!file) return;

    this.isParsing.set(true);
    try {
      const content = await this.fileParserService.parseFile(file);
      this.knowledgeService.addKnowledge(file.name, content);
    } catch (error) {
      console.error("Error parsing file:", error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      alert(`${this.errorParsingFileMsg()}: ${errorMessage}`);
    } finally {
      this.isParsing.set(false);
      this.selectedFile.set(null);
    }
  }
}


import { Injectable, inject } from '@angular/core';
import { SettingsService } from './settings.service';
import { KnowledgeService } from './knowledge.service';
import { GeminiService } from './gemini.service';
import { OpenaiService } from './openai.service';
import { DeepseekService } from './deepseek.service';
import { AiProviderType } from '../models/ai.model';
import { from } from 'rxjs';
import { TranslationService } from './translation.service';

@Injectable({ providedIn: 'root' })
export class AiService {
  private settingsService = inject(SettingsService);
  private knowledgeService = inject(KnowledgeService);
  private geminiService = inject(GeminiService);
  private openaiService = inject(OpenaiService);
  private deepseekService = inject(DeepseekService);
  private translationService = inject(TranslationService);

  private systemPrompt = this.translationService.translate('systemPrompt');

  sendMessage(userMessage: string) {
    const provider = this.settingsService.provider();
    const apiKey = this.settingsService.apiKey();
    const modelId = this.settingsService.modelId();
    const knowledgeContext = this.knowledgeService.getAllKnowledgeAsString();

    if (!provider || !apiKey || !modelId) {
        throw new Error('AI provider, API key, or model not configured.');
    }
    
    const fullPrompt = `${this.systemPrompt()}\n\n[USER KNOWLEDGE CONTEXT]:\n${knowledgeContext}\n\n[USER QUESTION]:\n${userMessage}`;

    switch (provider) {
      case 'gemini':
        return from(this.geminiService.generateResponse(apiKey, fullPrompt, modelId));
      case 'openai':
        return from(this.openaiService.generateResponse(apiKey, fullPrompt, modelId));
      case 'deepseek':
        return from(this.deepseekService.generateResponse(apiKey, fullPrompt, modelId));
      default:
        throw new Error(`Unsupported AI provider: ${provider}`);
    }
  }

  async verifyApiKey(apiKey: string, provider: AiProviderType, modelId: string): Promise<boolean> {
    if (!provider || !apiKey || !modelId) {
        return false;
    }
    
    try {
        switch (provider) {
          case 'gemini':
            return await this.geminiService.verifyApiKey(apiKey, modelId);
          case 'openai':
            return await this.openaiService.verifyApiKey(apiKey);
          case 'deepseek':
            return await this.deepseekService.verifyApiKey(apiKey);
          default:
            return false;
        }
    } catch (error) {
        console.error('API Key verification failed:', error);
        return false;
    }
  }
}

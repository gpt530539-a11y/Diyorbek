
import { Injectable, signal, computed, effect } from '@angular/core';
import { AiProviderType, Theme, Language } from '../models/ai.model';

@Injectable({ providedIn: 'root' })
export class SettingsService {
  private readonly API_KEY_STORAGE_KEY = 'assistant_private_chat_api_key';
  private readonly PROVIDER_STORAGE_KEY = 'assistant_private_chat_provider';
  private readonly MODEL_ID_STORAGE_KEY = 'assistant_private_chat_model_id';
  private readonly THEME_STORAGE_KEY = 'assistant_private_chat_theme';
  private readonly LANGUAGE_STORAGE_KEY = 'assistant_private_chat_language';

  apiKey = signal<string | null>(this.loadFromStorage(this.API_KEY_STORAGE_KEY));
  provider = signal<AiProviderType | null>(this.loadFromStorage(this.PROVIDER_STORAGE_KEY) as AiProviderType);
  modelId = signal<string | null>(this.loadFromStorage(this.MODEL_ID_STORAGE_KEY));
  theme = signal<Theme>((this.loadFromStorage(this.THEME_STORAGE_KEY) as Theme) || 'system');
  language = signal<Language>((this.loadFromStorage(this.LANGUAGE_STORAGE_KEY) as Language) || 'en');

  isConfigured = computed(() => !!this.apiKey() && !!this.provider() && !!this.modelId());

  constructor() {
    effect(() => {
      this.saveToStorage(this.API_KEY_STORAGE_KEY, this.apiKey());
      this.saveToStorage(this.PROVIDER_STORAGE_KEY, this.provider());
      this.saveToStorage(this.MODEL_ID_STORAGE_KEY, this.modelId());
      this.saveToStorage(this.THEME_STORAGE_KEY, this.theme());
      this.saveToStorage(this.LANGUAGE_STORAGE_KEY, this.language());
    });
  }

  saveSettings(apiKey: string, provider: AiProviderType, modelId: string) {
    this.apiKey.set(apiKey);
    this.provider.set(provider);
    this.modelId.set(modelId);
  }

  clearSettings() {
    this.apiKey.set(null);
    this.provider.set(null);
    this.modelId.set(null);
  }

  setTheme(theme: Theme) {
    this.theme.set(theme);
  }

  setLanguage(language: Language) {
    this.language.set(language);
  }

  private saveToStorage(key: string, value: string | null) {
    if (typeof window !== 'undefined') {
      if (value) {
        localStorage.setItem(key, value);
      } else {
        localStorage.removeItem(key);
      }
    }
  }

  private loadFromStorage(key: string): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(key);
    }
    return null;
  }
}

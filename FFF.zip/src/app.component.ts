
import { Component, ChangeDetectionStrategy, inject, effect } from '@angular/core';
import { SettingsService } from './services/settings.service';
import { SetupComponent } from './components/setup/setup.component';
import { MainComponent } from './components/main/main.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [SetupComponent, MainComponent],
})
export class AppComponent {
  settingsService = inject(SettingsService);
  isConfigured = this.settingsService.isConfigured;
  theme = this.settingsService.theme;

  constructor() {
    effect(() => {
      const currentTheme = this.theme();
      if (currentTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else if (currentTheme === 'light') {
        document.documentElement.classList.remove('dark');
      } else {
        // System theme
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    });

    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (this.theme() === 'system') {
            if (e.matches) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        }
    });
  }
}
